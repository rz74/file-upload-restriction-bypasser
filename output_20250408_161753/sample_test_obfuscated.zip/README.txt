== File Upload Bypass - Reconstruction Guide ==

Original Filename: sample_test.py
Character Shift Value: 2
Segments (10 total):
  - part_0
  - part_1
  - part_2
  - part_3
  - part_4
  - part_5
  - part_6
  - part_7
  - part_8
  - part_9

To reconstruct:
1. Concatenate all segments in order.
2. Shift characters back by the value above.
3. Base64 decode and save as the original file.
